//
//  SQExpandableTableViewCell.m
//  DarkWebPrefs
//
//  Created by Alex Gallon on 11/08/2018.
//  Copyright © 2018 Squ1dd13. All rights reserved.
//

#import "SQExpandableTableViewCell.h"

@implementation SQExpandableTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    self.selectionStyle = UITableViewCellSelectionStyleNone;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    if(selected) {
        self.frame = CGRectMake(self.frame.origin.x, self.frame.origin.y, self.frame.size.width, self.frame.size.height *2);
    } else {
        self.frame = CGRectMake(self.frame.origin.x, self.frame.origin.y, self.frame.size.width, self.frame.size.height /2);
    }
    
}

@end
