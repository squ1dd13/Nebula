//
//  SQTableViewController.m
//  DarkWebPrefs
//
//  Created by Alex Gallon on 11/08/2018.
//  Copyright © 2018 Squ1dd13. All rights reserved.
//

#import "SQTableViewController.h"
#import "SQExpandableTableViewCell.h"

@interface SQTableViewController () {
    NSArray *tableData;
}

@end

@implementation SQTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    tableData = @[@"cell", @"cell2"];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [tableData count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleTableIdentifier = @"SimpleTableItem";
    
    SQExpandableTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    
    if (cell == nil) {
        cell = [[SQExpandableTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:simpleTableIdentifier];
    }
    
    cell.textLabel.text = [tableData objectAtIndex:indexPath.row];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}


@end
