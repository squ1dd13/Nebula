//
//  SQExpandableTableViewCell.h
//  DarkWebPrefs
//
//  Created by Alex Gallon on 11/08/2018.
//  Copyright © 2018 Squ1dd13. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SQExpandableTableViewCell : UITableViewCell
@property (nonatomic, assign, readwrite) CGFloat height;
@end
