//
//  DWLoadingView.h
//  DarkWebLoading
//
//  Created by Alex Gallon on 12/08/2018.
//  Copyright © 2018 Squ1dd13. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DWLoadingView : UIView
@property (nonatomic, assign, readwrite) UIImage *icon;
@end
