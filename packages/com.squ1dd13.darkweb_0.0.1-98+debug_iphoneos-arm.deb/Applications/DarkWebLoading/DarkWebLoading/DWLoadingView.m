//
//  DWLoadingView.m
//  DarkWebLoading
//
//  Created by Alex Gallon on 12/08/2018.
//  Copyright © 2018 Squ1dd13. All rights reserved.
//

#import "DWLoadingView.h"

@implementation DWLoadingView

-(instancetype)initWithIcon:(UIImage *)icon frame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if(self) {
        self.icon = icon;
    }
    return self;
}

-(void)layoutSubviews {
    [super layoutSubviews];
    self.frame = [[UIApplication sharedApplication] keyWindow].frame;
    //first we need to set up the background
    self.backgroundColor = [UIColor clearColor];
    
    
    UIBlurEffect *blurEffect = [UIBlurEffect effectWithStyle:UIBlurEffectStyleDark];
    UIVibrancyEffect *vibrancyEffect = [UIVibrancyEffect effectForBlurEffect:blurEffect];
    
    UIVisualEffectView *visualEffectView = [[UIVisualEffectView alloc] initWithEffect:blurEffect];
    UIVisualEffectView *vibrantEffectView = [[UIVisualEffectView alloc] initWithEffect:vibrancyEffect];
    
    visualEffectView.frame = [[UIApplication sharedApplication] keyWindow].frame;
    vibrantEffectView.frame = [[UIApplication sharedApplication] keyWindow].frame;
    
    [self addSubview:vibrantEffectView];
    [self addSubview:visualEffectView]; //first part complete
    
    UIView *circleView = [[UIView alloc] initWithFrame:CGRectMake(self.frame.size.width /2, self.frame.size.height/2, 80, 80)];
    circleView.center = CGPointMake(self.frame.size.width /2, self.frame.size.height/3);
    circleView.layer.cornerRadius = 40;
    circleView.backgroundColor = [UIColor colorWithWhite:0.2 alpha:0.3];
    [self addSubview:circleView];
    
    
    UIImageView *iconImageView = [[UIImageView alloc] initWithFrame:circleView.frame];
    iconImageView.center = CGPointMake(circleView.frame.size.width /2, circleView.frame.size.height/3);
    
    UIImage *image = self.icon;
    iconImageView.image = image;
    [circleView addSubview:iconImageView];
    
    
    __block UILabel *loadingLabel = [[UILabel alloc] initWithFrame:CGRectMake(circleView.frame.origin.x, circleView.frame.origin.y-50, 120, 50)];
    
    loadingLabel.textAlignment = NSTextAlignmentCenter;
    loadingLabel.center = CGPointMake(self.frame.size.width /2, circleView.frame.origin.y+100);
    
    loadingLabel.font = [UIFont fontWithName:@".SFUIDisplay" size:26];
    
    [self addSubview:loadingLabel];

    __block int count = 0;
    id animateLabel = ^{
        if(count > 2) {
            count = 1;
        } else {
            count++;
        }

        [UIView transitionWithView:loadingLabel
                          duration:0.25f
                           options:UIViewAnimationOptionTransitionCrossDissolve
                        animations:^{
                            
                            loadingLabel.text = [NSString stringWithFormat:@"Loading%@",  [@"" stringByPaddingToLength:count withString:@"." startingAtIndex:0]];
                            
                        } completion:nil];
    };
    
    [NSTimer scheduledTimerWithTimeInterval:1.0
                                     target:animateLabel
                                   selector:@selector(invoke)
                                   userInfo:nil
                                    repeats:YES];
}

@end
