//
//  ViewController.h
//  DarkWebLoading
//
//  Created by Alex Gallon on 12/08/2018.
//  Copyright © 2018 Squ1dd13. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

